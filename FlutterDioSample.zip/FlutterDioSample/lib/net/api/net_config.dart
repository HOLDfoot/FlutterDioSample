
class NetConfig {
  static const DEBUG = true;
}